# Sample data for the Fabric Spark notebooks

Upload each CSV into your Lakehouse's **Files** area at the path shown, then run the matching
notebook. All files are comma-delimited with a header row.

| CSV file | Upload to (Lakehouse Files path) | Used by | Notes |
|---|---|---|---|
| `transactions_2026-01.csv` | `Files/raw/transactions/2026-01/` | 01 — Fundamentals | Columns: `txn_id, account_id, amount, txn_date, branch_code` |
| `patient_visits.csv` | `Files/raw/patient_visits/` | 03 — Ingestion & Transformation | Columns: `patient_id, visit_date, department, age, diagnosis_code`. Includes a few intentionally messy rows (bad date, missing department, negative age, missing patient_id) to exercise the `PERMISSIVE` / cleaning cells. |
| `transactions_2026-01-15.csv` | `Files/raw/transactions/2026-01-15/` | 07 — Real-World Medallion ETL | Columns: `txn_id, account_id, amount, currency, txn_ts, channel`. Includes an invalid currency (`XYZ`) and two rows with missing required fields to trigger the data-quality quarantine logic. Matches `run_date = "2026-01-15"` used in the notebook's parameters cell. |
| `accounts.csv` | Load directly with `spark.read.csv(...)` then `saveAsTable("accounts")`, or use in place of the inline `createDataFrame` example | 02 — Lakehouse & Delta Lake Deep Dive | Columns: `account_id, customer_name, account_type, balance, status`. A larger stand-in for the 3-row inline example, useful for testing `MERGE`, `OPTIMIZE ZORDER`, and `VACUUM` at a more realistic scale. |
| `department_dim.csv` | `Files/raw/dimensions/department_dim/` | 03 (join example) & 05 (broadcast join example) | Columns: `department, department_name, building`. Small dimension table intended for broadcast joins. |

## Quick load snippet

```python
df = (
    spark.read
    .option("header", True)
    .option("inferSchema", True)
    .csv("Files/raw/transactions/2026-01/transactions_2026-01.csv")
)
df.show(5)
```

For `patient_visits.csv` and `transactions_2026-01-15.csv`, use the explicit `StructType` schemas
already defined in notebooks 03 and 07 (rather than `inferSchema`) so the intentionally messy rows
are handled the way those notebooks demonstrate (`PERMISSIVE` mode / quarantine logic) instead of
silently breaking type inference.
