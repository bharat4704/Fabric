/* PROJECT 2 - Script 02: synthetic data (20 branches, 5,000 customers, 8,000 accounts, 100,000 transactions + planted structuring pattern) */

INSERT INTO dim.Branch
SELECT n, 'BR' + RIGHT('00' + CAST(n AS VARCHAR(2)), 2), 'NovaTrust Branch ' + CAST(n AS VARCHAR(2)),
       CHOOSE(1 + n % 6, 'Mumbai','Delhi','Bengaluru','Chennai','Vadodara','Kolkata'),
       CHOOSE(1 + n % 4, 'North','South','East','West')
FROM etl.vNumbers WHERE n <= 20;

INSERT INTO dim.Customer
SELECT n, 'NT' + RIGHT('000000' + CAST(n AS VARCHAR(6)), 6), 'Customer ' + CAST(n AS VARCHAR(6)),
       'customer' + CAST(n AS VARCHAR(6)) + '@example.com',
       '9' + RIGHT('000000000' + CAST(ABS(CHECKSUM(NEWID())) % 1000000000 AS VARCHAR(9)), 9),
       'ABCDE' + RIGHT('0000' + CAST(n AS VARCHAR(4)), 4) + 'F',
       CHOOSE(1 + ABS(CHECKSUM(NEWID())) % 10, 'Verified','Verified','Verified','Verified','Verified','Verified','Verified','Verified','Pending','Expired'),
       CHOOSE(1 + ABS(CHECKSUM(NEWID())) % 5, 'Low','Low','Medium','Medium','High')
FROM etl.vNumbers WHERE n <= 5000;

INSERT INTO dim.Account
SELECT n, '5010' + RIGHT('000000000000' + CAST(n AS VARCHAR(12)), 12), 1 + ABS(CHECKSUM(NEWID())) % 5000, 1 + ABS(CHECKSUM(NEWID())) % 20,
       CHOOSE(1 + ABS(CHECKSUM(NEWID())) % 3, 'Savings','Current','Salary'),
       DATEADD(DAY, -ABS(CHECKSUM(NEWID())) % 3000, CAST('2026-09-01' AS DATE))
FROM etl.vNumbers WHERE n <= 8000;

INSERT INTO fact.Txn
SELECT t.n, t.AccountKey, a.BranchKey, b.Region, t.TxnDate, t.TxnType, t.Channel, t.Amount
FROM (SELECT n, 1 + ABS(CHECKSUM(NEWID())) % 8000 AS AccountKey,
             DATEADD(DAY, ABS(CHECKSUM(NEWID())) % 240, CAST('2026-01-01' AS DATE)) AS TxnDate,
             CHOOSE(1 + ABS(CHECKSUM(NEWID())) % 4, 'Deposit','Withdrawal','Transfer','Payment') AS TxnType,
             CHOOSE(1 + ABS(CHECKSUM(NEWID())) % 5, 'Branch','ATM','UPI','NetBanking','Cash') AS Channel,
             CAST(CASE WHEN ABS(CHECKSUM(NEWID())) % 200 = 0 THEN 900000 + ABS(CHECKSUM(NEWID())) % 150000
                       ELSE 100 + ABS(CHECKSUM(NEWID())) % 50000 END AS DECIMAL(14,2)) AS Amount
      FROM etl.vNumbers WHERE n <= 100000) t
JOIN dim.Account a ON a.AccountKey = t.AccountKey
JOIN dim.Branch  b ON b.BranchKey  = a.BranchKey;

-- Planted AML "structuring" pattern: accounts 1..10 make 3 cash deposits just under the INR 10 lakh reporting limit on consecutive days
INSERT INTO fact.Txn
SELECT 100000 + (a.AccountKey * 10) + k.k, a.AccountKey, a.BranchKey, b.Region,
       DATEADD(DAY, k.k, CAST('2026-08-10' AS DATE)), 'Deposit', 'Cash', 950000 + k.k * 1000
FROM dim.Account a JOIN dim.Branch b ON b.BranchKey = a.BranchKey
CROSS JOIN (VALUES (0),(1),(2)) k(k)
WHERE a.AccountKey <= 10;

-- RLS access map. Replace with real Entra UPNs from your tenant.
INSERT INTO sec.UserRegion VALUES ('admin@yourtenant.onmicrosoft.com', 'ALL');
INSERT INTO sec.UserRegion VALUES ('west.manager@yourtenant.onmicrosoft.com', 'West');
INSERT INTO sec.UserRegion VALUES ('north.manager@yourtenant.onmicrosoft.com', 'North');
