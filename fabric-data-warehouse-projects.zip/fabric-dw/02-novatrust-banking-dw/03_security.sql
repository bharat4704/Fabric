/* PROJECT 2 - Script 03: security layers in Fabric Warehouse
   Layer 1: Dynamic Data Masking (declared in script 01)   Layer 2: Row-Level Security   Layer 3: column-level GRANT/DENY   */

-- ---------- Row-Level Security (inline TVF predicate + security policy) ----------
CREATE OR ALTER FUNCTION sec.fn_RegionFilter (@Region AS VARCHAR(20))
RETURNS TABLE WITH SCHEMABINDING AS
RETURN SELECT 1 AS allowed
       FROM sec.UserRegion u
       WHERE u.UserName = USER_NAME() AND (u.Region = @Region OR u.Region = 'ALL');

DROP SECURITY POLICY IF EXISTS sec.RegionPolicy;
CREATE SECURITY POLICY sec.RegionPolicy
    ADD FILTER PREDICATE sec.fn_RegionFilter(RegionCode) ON fact.Txn,
    ADD FILTER PREDICATE sec.fn_RegionFilter(Region)     ON dim.Branch
WITH (STATE = ON);
-- NOTE: with the policy ON, users NOT listed in sec.UserRegion see zero rows (including you). Add your own UPN first.

-- ---------- Masking: who can see real values ----------
-- GRANT UNMASK ON dim.Customer(Email) TO [compliance.officer@yourtenant.onmicrosoft.com];
-- Workspace Admin/Member/Contributor roles and the warehouse owner bypass masking by default; test with a user who only has Viewer/Read access.

-- ---------- Column-level security ----------
-- DENY SELECT ON OBJECT::dim.Customer(PAN) TO [analyst@yourtenant.onmicrosoft.com];

-- ---------- Verify ----------
SELECT USER_NAME() AS me;
SELECT Region, COUNT(*) AS txns FROM fact.Txn GROUP BY Region;  -- run as different users
SELECT TOP 5 CustomerNo, Email, Phone, PAN FROM dim.Customer;   -- run as a masked user
