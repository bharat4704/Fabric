/* PROJECT 2 - Script 04: AML / compliance analytics views */

-- 1) Cash transaction report: single cash deposits at or above INR 10 lakh
EXEC('CREATE OR ALTER VIEW rpt.vHighValueCash AS
SELECT t.TxnId, t.TxnDate, a.AccountNo, c.CustomerNo, c.RiskRating, t.Amount, t.RegionCode
FROM fact.Txn t JOIN dim.Account a ON a.AccountKey = t.AccountKey JOIN dim.Customer c ON c.CustomerKey = a.CustomerKey
WHERE t.Channel = ''Cash'' AND t.TxnType = ''Deposit'' AND t.Amount >= 1000000');

-- 2) Structuring: 2+ cash deposits between 9 and 10 lakh by one account within 7 days
EXEC('CREATE OR ALTER VIEW rpt.vStructuringSuspects AS
WITH d AS (
  SELECT AccountKey, TxnDate, Amount,
         COUNT(*) OVER (PARTITION BY AccountKey ORDER BY TxnDate ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS cnt_7d,
         SUM(Amount) OVER (PARTITION BY AccountKey ORDER BY TxnDate ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS sum_7d
  FROM fact.Txn WHERE Channel = ''Cash'' AND TxnType = ''Deposit'' AND Amount BETWEEN 900000 AND 999999)
SELECT a.AccountNo, MAX(d.cnt_7d) AS MaxDepositsIn7d, MAX(d.sum_7d) AS MaxAmountIn7d
FROM d JOIN dim.Account a ON a.AccountKey = d.AccountKey
GROUP BY a.AccountNo HAVING MAX(d.cnt_7d) >= 2');

-- 3) Velocity: accounts with 10+ transactions in one day
EXEC('CREATE OR ALTER VIEW rpt.vVelocityAlerts AS
SELECT a.AccountNo, t.TxnDate, COUNT(*) AS TxnCount, SUM(t.Amount) AS TotalAmount
FROM fact.Txn t JOIN dim.Account a ON a.AccountKey = t.AccountKey
GROUP BY a.AccountNo, t.TxnDate HAVING COUNT(*) >= 10');

-- 4) Alert priority: join suspects to KYC/risk profile
EXEC('CREATE OR ALTER VIEW rpt.vAlertPriority AS
SELECT s.AccountNo, s.MaxDepositsIn7d, s.MaxAmountIn7d, c.RiskRating, c.KycStatus,
       CASE WHEN c.RiskRating = ''High'' OR c.KycStatus <> ''Verified'' THEN ''P1'' ELSE ''P2'' END AS Priority
FROM rpt.vStructuringSuspects s
JOIN dim.Account a ON a.AccountNo = s.AccountNo JOIN dim.Customer c ON c.CustomerKey = a.CustomerKey');

SELECT * FROM rpt.vAlertPriority ORDER BY Priority, MaxAmountIn7d DESC;
