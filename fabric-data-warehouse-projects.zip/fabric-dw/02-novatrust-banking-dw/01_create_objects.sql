/* PROJECT 2 - NovaTrustDW (banking, security-focused) | Script 01: schemas + tables with Dynamic Data Masking
   Create an empty Fabric Warehouse named NovaTrustDW first. */

IF SCHEMA_ID('dim') IS NULL EXEC('CREATE SCHEMA dim');
IF SCHEMA_ID('fact') IS NULL EXEC('CREATE SCHEMA fact');
IF SCHEMA_ID('sec') IS NULL EXEC('CREATE SCHEMA sec');
IF SCHEMA_ID('rpt') IS NULL EXEC('CREATE SCHEMA rpt');
IF SCHEMA_ID('etl') IS NULL EXEC('CREATE SCHEMA etl');

EXEC('CREATE OR ALTER VIEW etl.vNumbers AS
WITH dg AS (SELECT v FROM (VALUES (0),(1),(2),(3),(4),(5),(6),(7),(8),(9)) t(v))
SELECT 1 + a.v + 10*b.v + 100*c.v + 1000*d.v + 10000*e.v AS n
FROM dg a CROSS JOIN dg b CROSS JOIN dg c CROSS JOIN dg d CROSS JOIN dg e');

DROP TABLE IF EXISTS dim.Branch;
CREATE TABLE dim.Branch (BranchKey INT NOT NULL, BranchCode VARCHAR(10), BranchName VARCHAR(100), City VARCHAR(50), Region VARCHAR(20));

DROP TABLE IF EXISTS dim.Customer;
CREATE TABLE dim.Customer (
    CustomerKey INT NOT NULL, CustomerNo VARCHAR(15), FullName VARCHAR(100),
    Email   VARCHAR(100) MASKED WITH (FUNCTION = 'email()'),
    Phone   VARCHAR(15)  MASKED WITH (FUNCTION = 'partial(0,"XXXXXX",4)'),
    PAN     VARCHAR(10)  MASKED WITH (FUNCTION = 'default()'),
    KycStatus VARCHAR(15), RiskRating VARCHAR(10));

DROP TABLE IF EXISTS dim.Account;
CREATE TABLE dim.Account (AccountKey INT NOT NULL, AccountNo VARCHAR(16), CustomerKey INT, BranchKey INT, AccountType VARCHAR(15), OpenDate DATE);

DROP TABLE IF EXISTS fact.Txn;
CREATE TABLE fact.Txn (TxnId BIGINT NOT NULL, AccountKey INT, BranchKey INT, RegionCode VARCHAR(20), TxnDate DATE, TxnType VARCHAR(15), Channel VARCHAR(15), Amount DECIMAL(14,2));

-- Access map used by Row-Level Security: which user may see which region ('ALL' = every region)
DROP TABLE IF EXISTS sec.UserRegion;
CREATE TABLE sec.UserRegion (UserName VARCHAR(128), Region VARCHAR(20));
