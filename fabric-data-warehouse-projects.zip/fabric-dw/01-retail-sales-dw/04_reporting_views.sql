/* PROJECT 1 - Script 04: semantic-layer views (use these when building the default Power BI semantic model) */

EXEC('CREATE OR ALTER VIEW rpt.vSalesDetail AS
SELECT f.SalesKey, d.FullDate, d.[Year], d.[Quarter], d.MonthName, c.CustomerID, c.Segment, c.City AS CustomerCity,
       p.ProductName, p.Category, p.Brand, s.StoreName, s.Region, f.Quantity, f.SalesAmount, f.CostAmount, f.SalesAmount - f.CostAmount AS Profit
FROM fact.FactSales f
JOIN dim.DimDate d ON d.DateKey = f.OrderDateKey
JOIN dim.DimCustomer c ON c.CustomerKey = f.CustomerKey
JOIN dim.DimProduct p ON p.ProductKey = f.ProductKey
JOIN dim.DimStore s ON s.StoreKey = f.StoreKey');

-- Monthly revenue with MoM and YoY growth (LAG)
EXEC('CREATE OR ALTER VIEW rpt.vMonthlyTrend AS
WITH m AS (
  SELECT d.[Year], d.[Month], SUM(f.SalesAmount) AS Revenue, SUM(f.SalesAmount - f.CostAmount) AS Profit
  FROM fact.FactSales f JOIN dim.DimDate d ON d.DateKey = f.OrderDateKey GROUP BY d.[Year], d.[Month])
SELECT [Year], [Month], Revenue, Profit,
       Revenue - LAG(Revenue, 1) OVER (ORDER BY [Year], [Month]) AS MoM_Change,
       (Revenue - LAG(Revenue, 12) OVER (ORDER BY [Year], [Month])) * 100.0 / NULLIF(LAG(Revenue, 12) OVER (ORDER BY [Year], [Month]), 0) AS YoY_Pct,
       SUM(Revenue) OVER (PARTITION BY [Year] ORDER BY [Month] ROWS UNBOUNDED PRECEDING) AS YTD_Revenue
FROM m');

-- Top 5 products per category (RANK)
EXEC('CREATE OR ALTER VIEW rpt.vTopProductsByCategory AS
SELECT * FROM (
  SELECT p.Category, p.ProductName, SUM(f.SalesAmount) AS Revenue,
         RANK() OVER (PARTITION BY p.Category ORDER BY SUM(f.SalesAmount) DESC) AS rnk
  FROM fact.FactSales f JOIN dim.DimProduct p ON p.ProductKey = f.ProductKey GROUP BY p.Category, p.ProductName) x
WHERE rnk <= 5');

-- Customer value tiers (NTILE)
EXEC('CREATE OR ALTER VIEW rpt.vCustomerTiers AS
SELECT CustomerID, Revenue, NTILE(4) OVER (ORDER BY Revenue DESC) AS ValueQuartile FROM (
  SELECT c.CustomerID, SUM(f.SalesAmount) AS Revenue
  FROM fact.FactSales f JOIN dim.DimCustomer c ON c.CustomerKey = f.CustomerKey GROUP BY c.CustomerID) t');

SELECT TOP 12 * FROM rpt.vMonthlyTrend ORDER BY [Year], [Month];
