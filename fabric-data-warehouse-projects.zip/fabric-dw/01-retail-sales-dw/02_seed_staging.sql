/* PROJECT 1 - Script 02: generate synthetic source data into staging (2,000 customers, 200 products, 20 stores, 100,000 sales lines) */

TRUNCATE TABLE stg.Customer;
INSERT INTO stg.Customer
SELECT 'C' + RIGHT('00000' + CAST(n AS VARCHAR(5)), 5),
       'Customer ' + CAST(n AS VARCHAR(5)),
       CHOOSE(1 + ABS(CHECKSUM(NEWID())) % 6, 'Mumbai','Delhi','Bengaluru','Chennai','Vadodara','Pune'),
       CHOOSE(1 + ABS(CHECKSUM(NEWID())) % 3, 'Consumer','Corporate','Home Office')
FROM etl.vNumbers WHERE n <= 2000;

TRUNCATE TABLE stg.Product;
INSERT INTO stg.Product
SELECT 'P' + RIGHT('000' + CAST(n AS VARCHAR(3)), 3),
       'Product ' + CAST(n AS VARCHAR(3)),
       CHOOSE(1 + n % 5, 'Electronics','Apparel','Home','Grocery','Sports'),
       CHOOSE(1 + ABS(CHECKSUM(NEWID())) % 4, 'Alpha','Bravo','Cosmo','Delta'),
       CAST(20 + ABS(CHECKSUM(NEWID())) % 400 AS DECIMAL(10,2)),
       CAST(0 AS DECIMAL(10,2))
FROM etl.vNumbers WHERE n <= 200;
UPDATE stg.Product SET ListPrice = ROUND(StdCost * 1.35, 2);

TRUNCATE TABLE stg.Store;
INSERT INTO stg.Store
SELECT 'S' + RIGHT('00' + CAST(n AS VARCHAR(2)), 2), 'Store ' + CAST(n AS VARCHAR(2)),
       CHOOSE(1 + n % 6, 'Mumbai','Delhi','Bengaluru','Chennai','Vadodara','Pune'),
       CHOOSE(1 + n % 4, 'North','South','East','West')
FROM etl.vNumbers WHERE n <= 20;

TRUNCATE TABLE stg.SalesLine;
INSERT INTO stg.SalesLine
SELECT n,
       DATEADD(DAY, ABS(CHECKSUM(NEWID())) % 730, CAST('2024-01-01' AS DATE)),
       'C' + RIGHT('00000' + CAST(1 + ABS(CHECKSUM(NEWID())) % 2000 AS VARCHAR(5)), 5),
       'P' + RIGHT('000'   + CAST(1 + ABS(CHECKSUM(NEWID())) % 200  AS VARCHAR(3)), 3),
       'S' + RIGHT('00'    + CAST(1 + ABS(CHECKSUM(NEWID())) % 20   AS VARCHAR(2)), 2),
       1 + ABS(CHECKSUM(NEWID())) % 5,
       CAST(30 + ABS(CHECKSUM(NEWID())) % 600 AS DECIMAL(10,2)),
       CHOOSE(1 + ABS(CHECKSUM(NEWID())) % 4, 0.00, 0.05, 0.10, 0.20)
FROM etl.vNumbers WHERE n <= 100000;

SELECT 'Customer' t, COUNT(*) c FROM stg.Customer UNION ALL SELECT 'Product', COUNT(*) FROM stg.Product
UNION ALL SELECT 'Store', COUNT(*) FROM stg.Store UNION ALL SELECT 'SalesLine', COUNT(*) FROM stg.SalesLine;
