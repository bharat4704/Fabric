/* PROJECT 1 - Script 03: ETL stored procedures (log + TRY/CATCH pattern), SCD1 product, SCD2 customer, incremental fact.
   Orchestrate etl.usp_Run_All from a Fabric Data Pipeline "Stored procedure" activity. */

CREATE OR ALTER PROCEDURE etl.usp_Log @ProcName VARCHAR(100), @Rows INT, @Status VARCHAR(20), @Msg VARCHAR(4000)
AS
BEGIN
    DECLARE @id INT = (SELECT ISNULL(MAX(RunId), 0) + 1 FROM etl.RunLog);
    INSERT INTO etl.RunLog VALUES (@id, @ProcName, SYSDATETIME(), @Rows, @Status, @Msg);
END;

CREATE OR ALTER PROCEDURE etl.usp_Load_DimDate AS
BEGIN
    BEGIN TRY
        TRUNCATE TABLE dim.DimDate;
        INSERT INTO dim.DimDate
        SELECT YEAR(d)*10000 + MONTH(d)*100 + DAY(d), d, YEAR(d), DATEPART(QUARTER, d), MONTH(d), DATENAME(MONTH, d),
               DAY(d), DATENAME(WEEKDAY, d), CASE WHEN DATENAME(WEEKDAY, d) IN ('Saturday','Sunday') THEN 1 ELSE 0 END
        FROM (SELECT DATEADD(DAY, n - 1, CAST('2024-01-01' AS DATE)) AS d FROM etl.vNumbers WHERE n <= 1096) x;
        EXEC etl.usp_Log 'usp_Load_DimDate', 1096, 'Success', NULL;
    END TRY
    BEGIN CATCH
        DECLARE @m VARCHAR(4000) = ERROR_MESSAGE();
        EXEC etl.usp_Log 'usp_Load_DimDate', 0, 'Failed', @m;
        THROW;
    END CATCH
END;

CREATE OR ALTER PROCEDURE etl.usp_Load_DimProduct AS   -- SCD Type 1: overwrite changes, insert new
BEGIN
    BEGIN TRY
        UPDATE d SET ProductName = s.ProductName, Category = s.Category, Brand = s.Brand, StdCost = s.StdCost, ListPrice = s.ListPrice
        FROM dim.DimProduct d JOIN stg.Product s ON s.ProductID = d.ProductID
        WHERE d.ProductName <> s.ProductName OR d.Category <> s.Category OR d.Brand <> s.Brand OR d.StdCost <> s.StdCost OR d.ListPrice <> s.ListPrice;

        DECLARE @max INT = (SELECT ISNULL(MAX(ProductKey), 0) FROM dim.DimProduct);
        INSERT INTO dim.DimProduct
        SELECT @max + ROW_NUMBER() OVER (ORDER BY s.ProductID), s.ProductID, s.ProductName, s.Category, s.Brand, s.StdCost, s.ListPrice
        FROM stg.Product s WHERE NOT EXISTS (SELECT 1 FROM dim.DimProduct d WHERE d.ProductID = s.ProductID);
        EXEC etl.usp_Log 'usp_Load_DimProduct', @@ROWCOUNT, 'Success', NULL;
    END TRY
    BEGIN CATCH
        DECLARE @m VARCHAR(4000) = ERROR_MESSAGE();
        EXEC etl.usp_Log 'usp_Load_DimProduct', 0, 'Failed', @m;
        THROW;
    END CATCH
END;

CREATE OR ALTER PROCEDURE etl.usp_Load_DimStore AS
BEGIN
    BEGIN TRY
        DECLARE @max INT = (SELECT ISNULL(MAX(StoreKey), 0) FROM dim.DimStore);
        INSERT INTO dim.DimStore
        SELECT @max + ROW_NUMBER() OVER (ORDER BY s.StoreID), s.StoreID, s.StoreName, s.City, s.Region
        FROM stg.Store s WHERE NOT EXISTS (SELECT 1 FROM dim.DimStore d WHERE d.StoreID = s.StoreID);
        EXEC etl.usp_Log 'usp_Load_DimStore', @@ROWCOUNT, 'Success', NULL;
    END TRY
    BEGIN CATCH
        DECLARE @m VARCHAR(4000) = ERROR_MESSAGE();
        EXEC etl.usp_Log 'usp_Load_DimStore', 0, 'Failed', @m;
        THROW;
    END CATCH
END;

CREATE OR ALTER PROCEDURE etl.usp_Load_DimCustomer AS  -- SCD Type 2: expire changed rows, then insert new/changed versions
BEGIN
    BEGIN TRY
        DECLARE @today DATE = CAST(GETDATE() AS DATE);
        DECLARE @first BIT = CASE WHEN EXISTS (SELECT 1 FROM dim.DimCustomer) THEN 0 ELSE 1 END;

        UPDATE d SET EffectiveTo = DATEADD(DAY, -1, @today), IsCurrent = 0
        FROM dim.DimCustomer d JOIN stg.Customer s ON s.CustomerID = d.CustomerID
        WHERE d.IsCurrent = 1 AND (d.City <> s.City OR d.Segment <> s.Segment OR d.CustomerName <> s.CustomerName);

        DECLARE @max INT = (SELECT ISNULL(MAX(CustomerKey), 0) FROM dim.DimCustomer);
        INSERT INTO dim.DimCustomer
        SELECT @max + ROW_NUMBER() OVER (ORDER BY s.CustomerID), s.CustomerID, s.CustomerName, s.City, s.Segment,
               CASE WHEN @first = 1 THEN CAST('1900-01-01' AS DATE) ELSE @today END, CAST('9999-12-31' AS DATE), 1
        FROM stg.Customer s
        LEFT JOIN dim.DimCustomer d ON d.CustomerID = s.CustomerID AND d.IsCurrent = 1
        WHERE d.CustomerID IS NULL;
        EXEC etl.usp_Log 'usp_Load_DimCustomer', @@ROWCOUNT, 'Success', NULL;
    END TRY
    BEGIN CATCH
        DECLARE @m VARCHAR(4000) = ERROR_MESSAGE();
        EXEC etl.usp_Log 'usp_Load_DimCustomer', 0, 'Failed', @m;
        THROW;
    END CATCH
END;

CREATE OR ALTER PROCEDURE etl.usp_Load_FactSales AS    -- incremental: only OrderLineIDs not already loaded; point-in-time SCD2 join
BEGIN
    BEGIN TRY
        DECLARE @max INT = (SELECT ISNULL(MAX(SalesKey), 0) FROM fact.FactSales);
        INSERT INTO fact.FactSales
        SELECT @max + ROW_NUMBER() OVER (ORDER BY s.OrderLineID), s.OrderLineID,
               YEAR(s.OrderDate)*10000 + MONTH(s.OrderDate)*100 + DAY(s.OrderDate),
               c.CustomerKey, p.ProductKey, st.StoreKey, s.Quantity, s.UnitPrice, s.DiscountPct,
               CAST(s.Quantity * s.UnitPrice * (1 - s.DiscountPct) AS DECIMAL(14,2)),
               CAST(s.Quantity * p.StdCost AS DECIMAL(14,2)), SYSDATETIME()
        FROM stg.SalesLine s
        JOIN dim.DimCustomer c ON c.CustomerID = s.CustomerID AND s.OrderDate BETWEEN c.EffectiveFrom AND c.EffectiveTo
        JOIN dim.DimProduct  p ON p.ProductID  = s.ProductID
        JOIN dim.DimStore   st ON st.StoreID   = s.StoreID
        WHERE NOT EXISTS (SELECT 1 FROM fact.FactSales f WHERE f.OrderLineID = s.OrderLineID);
        EXEC etl.usp_Log 'usp_Load_FactSales', @@ROWCOUNT, 'Success', NULL;
    END TRY
    BEGIN CATCH
        DECLARE @m VARCHAR(4000) = ERROR_MESSAGE();
        EXEC etl.usp_Log 'usp_Load_FactSales', 0, 'Failed', @m;
        THROW;
    END CATCH
END;

CREATE OR ALTER PROCEDURE etl.usp_Run_All AS
BEGIN
    EXEC etl.usp_Load_DimDate;
    EXEC etl.usp_Load_DimProduct;
    EXEC etl.usp_Load_DimStore;
    EXEC etl.usp_Load_DimCustomer;
    EXEC etl.usp_Load_FactSales;
END;
