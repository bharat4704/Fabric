/* PROJECT 1 - RetailDW | Script 01: schemas, dimensions, fact, staging, ETL log
   Run against an empty Fabric Warehouse named RetailDW.
   Fabric notes: no NVARCHAR (use VARCHAR), DATETIME2 max precision 6, keys are NOT ENFORCED. */

IF SCHEMA_ID('stg')  IS NULL EXEC('CREATE SCHEMA stg');
IF SCHEMA_ID('dim')  IS NULL EXEC('CREATE SCHEMA dim');
IF SCHEMA_ID('fact') IS NULL EXEC('CREATE SCHEMA fact');
IF SCHEMA_ID('etl')  IS NULL EXEC('CREATE SCHEMA etl');
IF SCHEMA_ID('rpt')  IS NULL EXEC('CREATE SCHEMA rpt');

-- ---------- Staging ----------
DROP TABLE IF EXISTS stg.Customer;
CREATE TABLE stg.Customer (CustomerID VARCHAR(20), CustomerName VARCHAR(100), City VARCHAR(50), Segment VARCHAR(20));
DROP TABLE IF EXISTS stg.Product;
CREATE TABLE stg.Product (ProductID VARCHAR(20), ProductName VARCHAR(100), Category VARCHAR(50), Brand VARCHAR(50), StdCost DECIMAL(10,2), ListPrice DECIMAL(10,2));
DROP TABLE IF EXISTS stg.Store;
CREATE TABLE stg.Store (StoreID VARCHAR(10), StoreName VARCHAR(100), City VARCHAR(50), Region VARCHAR(20));
DROP TABLE IF EXISTS stg.SalesLine;
CREATE TABLE stg.SalesLine (OrderLineID BIGINT, OrderDate DATE, CustomerID VARCHAR(20), ProductID VARCHAR(20), StoreID VARCHAR(10), Quantity INT, UnitPrice DECIMAL(10,2), DiscountPct DECIMAL(5,2));

-- ---------- Dimensions ----------
DROP TABLE IF EXISTS dim.DimDate;
CREATE TABLE dim.DimDate (DateKey INT NOT NULL, FullDate DATE NOT NULL, [Year] SMALLINT, [Quarter] TINYINT, [Month] TINYINT, MonthName VARCHAR(12),
                          [Day] TINYINT, DayName VARCHAR(12), IsWeekend BIT);
ALTER TABLE dim.DimDate ADD CONSTRAINT PK_DimDate PRIMARY KEY NONCLUSTERED (DateKey) NOT ENFORCED;

DROP TABLE IF EXISTS dim.DimCustomer;   -- SCD Type 2
CREATE TABLE dim.DimCustomer (CustomerKey INT NOT NULL, CustomerID VARCHAR(20) NOT NULL, CustomerName VARCHAR(100), City VARCHAR(50), Segment VARCHAR(20),
                              EffectiveFrom DATE NOT NULL, EffectiveTo DATE NOT NULL, IsCurrent BIT NOT NULL);
ALTER TABLE dim.DimCustomer ADD CONSTRAINT PK_DimCustomer PRIMARY KEY NONCLUSTERED (CustomerKey) NOT ENFORCED;

DROP TABLE IF EXISTS dim.DimProduct;    -- SCD Type 1
CREATE TABLE dim.DimProduct (ProductKey INT NOT NULL, ProductID VARCHAR(20) NOT NULL, ProductName VARCHAR(100), Category VARCHAR(50), Brand VARCHAR(50),
                             StdCost DECIMAL(10,2), ListPrice DECIMAL(10,2));
ALTER TABLE dim.DimProduct ADD CONSTRAINT PK_DimProduct PRIMARY KEY NONCLUSTERED (ProductKey) NOT ENFORCED;

DROP TABLE IF EXISTS dim.DimStore;
CREATE TABLE dim.DimStore (StoreKey INT NOT NULL, StoreID VARCHAR(10) NOT NULL, StoreName VARCHAR(100), City VARCHAR(50), Region VARCHAR(20));
ALTER TABLE dim.DimStore ADD CONSTRAINT PK_DimStore PRIMARY KEY NONCLUSTERED (StoreKey) NOT ENFORCED;

-- ---------- Fact ----------
DROP TABLE IF EXISTS fact.FactSales;
CREATE TABLE fact.FactSales (SalesKey INT NOT NULL, OrderLineID BIGINT NOT NULL, OrderDateKey INT NOT NULL, CustomerKey INT NOT NULL, ProductKey INT NOT NULL,
                             StoreKey INT NOT NULL, Quantity INT, UnitPrice DECIMAL(10,2), DiscountPct DECIMAL(5,2), SalesAmount DECIMAL(14,2),
                             CostAmount DECIMAL(14,2), LoadedAt DATETIME2(3));
ALTER TABLE fact.FactSales ADD CONSTRAINT PK_FactSales PRIMARY KEY NONCLUSTERED (SalesKey) NOT ENFORCED;
ALTER TABLE fact.FactSales ADD CONSTRAINT FK_FactSales_Product FOREIGN KEY (ProductKey) REFERENCES dim.DimProduct (ProductKey) NOT ENFORCED;

-- ---------- ETL log ----------
DROP TABLE IF EXISTS etl.RunLog;
CREATE TABLE etl.RunLog (RunId INT, ProcName VARCHAR(100), LoggedAt DATETIME2(3), RowsAffected INT, Status VARCHAR(20), Message VARCHAR(4000));

-- ---------- Helper numbers view (1..100000) ----------
EXEC('CREATE OR ALTER VIEW etl.vNumbers AS
WITH dg AS (SELECT v FROM (VALUES (0),(1),(2),(3),(4),(5),(6),(7),(8),(9)) t(v))
SELECT 1 + a.v + 10*b.v + 100*c.v + 1000*d.v + 10000*e.v AS n
FROM dg a CROSS JOIN dg b CROSS JOIN dg c CROSS JOIN dg d CROSS JOIN dg e');
