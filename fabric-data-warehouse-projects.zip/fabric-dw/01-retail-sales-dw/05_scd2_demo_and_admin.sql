/* PROJECT 1 - Script 05: SCD2 demo + Fabric warehouse admin features */

-- A) SCD2 demo: move 5 customers to a new city, rerun the customer load, inspect history
UPDATE stg.Customer SET City = 'Ahmedabad' WHERE CustomerID IN ('C00001','C00002','C00003','C00004','C00005');
EXEC etl.usp_Load_DimCustomer;
SELECT CustomerID, City, EffectiveFrom, EffectiveTo, IsCurrent FROM dim.DimCustomer
WHERE CustomerID IN ('C00001','C00002') ORDER BY CustomerID, EffectiveFrom;

-- B) Statistics after big loads
UPDATE STATISTICS fact.FactSales;
CREATE STATISTICS st_FactSales_Date ON fact.FactSales (OrderDateKey);

-- C) Zero-copy clone (instant, no data duplication) - handy for dev/test and pre-change backups
DROP TABLE IF EXISTS fact.FactSales_Clone;
CREATE TABLE fact.FactSales_Clone AS CLONE OF fact.FactSales;

-- D) Time travel (query the table as it was; use a UTC timestamp within the retention window)
-- SELECT COUNT(*) FROM fact.FactSales OPTION (FOR TIMESTAMP AS OF '2026-09-20T10:00:00.000');

-- E) Monitor: slowest queries (Query Insights)
SELECT TOP 10 start_time, total_elapsed_time_ms, row_count, LEFT(command, 200) AS cmd
FROM queryinsights.exec_requests_history ORDER BY total_elapsed_time_ms DESC;

-- F) ETL audit
SELECT * FROM etl.RunLog ORDER BY RunId DESC;
