# Microsoft Fabric Data Warehouse Projects (3 hands-on builds)

| # | Project | Domain | What it teaches |
|---|---------|--------|-----------------|
| 1 | `01-retail-sales-dw` | Retail | Star schema, SCD Type 1 + Type 2, incremental fact loads, ETL logging with TRY/CATCH, window-function reporting views, clones, time travel, Query Insights |
| 2 | `02-novatrust-banking-dw` | Banking / AML | Dynamic Data Masking, Row-Level Security, column-level security, AML analytics (cash reports, structuring, velocity) |
| 3 | `03-hospital-ops-dw` | Healthcare | Lakehouse + Warehouse pattern: Spark generates Delta tables, Warehouse loads via cross-database queries; ALOS, 30-day readmission, bed occupancy |

## Prerequisites
- A Fabric workspace on a paid or trial capacity.
- Projects 1 and 2: one empty **Warehouse** each (`RetailDW`, `NovaTrustDW`).
- Project 3: a **Lakehouse** `HospitalLH` and a **Warehouse** `HospitalDW` in the same workspace.

## Run order
Open the warehouse's **New SQL query** editor and run the scripts in numeric order. The Fabric editor may not accept `GO`, so none are used. If a multi-statement script complains, select and run one block at a time.

**Project 1 - RetailDW:** `01_create_objects` -> `02_seed_staging` -> `03_etl_procedures` -> `EXEC etl.usp_Run_All;` -> `04_reporting_views` -> `05_scd2_demo_and_admin`
**Project 2 - NovaTrustDW:** `01_create_objects` -> `02_seed_data` -> `03_security` (edit the UPNs first!) -> `04_aml_reporting`
**Project 3 - HospitalDW:** run `00_generate_lakehouse_data.py` in a Notebook attached to HospitalLH -> `01_create_objects` -> `02_load_from_lakehouse` -> `03_kpi_views`

## Suggested Fabric extensions (portfolio / training exercises)
1. **Orchestrate**: Data Pipeline with a *Stored procedure* activity calling `etl.usp_Run_All` (Project 1) or `etl.usp_Load_Hospital` (Project 3), an *If Condition* on failure, and a schedule trigger.
2. **Semantic model**: create a Direct Lake / default semantic model over the `dim`/`fact`/`rpt` objects, define relationships, add DAX measures (Revenue, Profit %, YoY %), and build a report.
3. **Governance**: apply Microsoft Purview sensitivity labels to `dim.Customer` (Project 2) and check lineage view across Lakehouse -> Warehouse -> report (Project 3).
4. **CI/CD**: connect the workspace to Git, or use a Warehouse database project and deployment pipelines (Dev -> Test -> Prod).
5. **Performance lab**: scale Project 1 to millions of rows, compare queries before/after `UPDATE STATISTICS`, and inspect them in `queryinsights.*`.

## Fabric Warehouse gotchas used in these scripts
- Data types: `VARCHAR` (not NVARCHAR), `DATETIME2(n<=6)`. Primary/foreign/unique keys are metadata only, so declare them `NOT ENFORCED`. Uniqueness is your ETL's job (hence the `NOT EXISTS` load patterns).
- Surrogate keys use `MAX()+ROW_NUMBER()` instead of IDENTITY, which is portable across setups.
- Tables are Delta/Parquet in OneLake, so the same data is readable from Spark, and cross-database queries work across items in one workspace.

## Validation note
These scripts were written against Fabric Warehouse T-SQL conventions but were not executed against a live Fabric tenant in this session. Run script by script and adjust anything your tenant's feature set rejects (for example RLS predicate on `USER_NAME()` vs UPN format, or clone syntax availability).
